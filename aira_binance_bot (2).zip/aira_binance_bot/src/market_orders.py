import sys
from binance.client import Client
from config import API_KEY, API_SECRET, BASE_URL
from validator import *
from logger import info, error

client = Client(API_KEY, API_SECRET)
client.FUTURES_URL = BASE_URL

def market_order(symbol, side, qty):
    validate_symbol(symbol)
    validate_side(side)
    validate_quantity(qty)
    try:
        order = client.futures_create_order(
            symbol=symbol,
            side=side,
            type="MARKET",
            quantity=qty
        )
        info(
    f"Market Order Executed | "
    f"Symbol={symbol} | Side={side} | Qty={qty}"
)

    except Exception as e:
        error(str(e))

if __name__ == "__main__":
    _, symbol, side, qty = sys.argv
    market_order(symbol, side, float(qty))
