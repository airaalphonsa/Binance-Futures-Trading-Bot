def stop_limit(symbol, side, qty, stop_price, limit_price):
    pass
