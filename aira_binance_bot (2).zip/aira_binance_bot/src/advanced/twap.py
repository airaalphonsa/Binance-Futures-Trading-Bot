def twap(symbol, side, total_qty, slices, interval):
    pass
