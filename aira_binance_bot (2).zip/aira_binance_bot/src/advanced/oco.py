def oco_order(symbol, qty, take_profit, stop_loss):
    pass
