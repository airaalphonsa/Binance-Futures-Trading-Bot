def grid_trade(symbol, low, high, grids):
    pass
