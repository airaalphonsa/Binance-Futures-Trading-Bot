import sys
from binance.client import Client
from config import *
from validator import *
from logger import info, error

client = Client(API_KEY, API_SECRET)
client.FUTURES_URL = BASE_URL

def limit_order(symbol, side, qty, price):
    validate_symbol(symbol)
    validate_side(side)
    validate_quantity(qty)
    validate_price(price)
    try:
        order = client.futures_create_order(
            symbol=symbol,
            side=side,
            type="LIMIT",
            quantity=qty,
            price=price,
            timeInForce="GTC"
        )
        info(f"Limit Order Placed | {order}")
    except Exception as e:
        error(str(e))

if __name__ == "__main__":
    _, symbol, side, qty, price = sys.argv
    limit_order(symbol, side, float(qty), float(price))
