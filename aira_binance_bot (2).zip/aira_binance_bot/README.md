# Binance Futures Order Bot (Testnet)

## Setup
1. Create Binance Futures Testnet API keys
2. Add keys in src/config.py
3. Install dependencies:
   pip install python-binance

## Run
python src/market_orders.py BTCUSDT BUY 0.01
python src/limit_orders.py BTCUSDT SELL 0.01 65000
